{
Demo:"Watch online demonstrations",
Library:"Visit the Oracle Learning Library for SQL Developer Data Modeler tutorials",
Manual:"Read the SQL Developer Data Modeler user manual",
Requests:"Add to or vote on new feature requests; share Oracle SQL Developer Data Modeler tips, snippets and reports",
Forum:"Participate in the SQL Developer Data Modeler discussion forum",
Course:"Review the Oracle University Data Modeling Course",
Online:"Read the online database documentation for SQL and PL/SQL syntax and learn more about the Oracle database"
}
