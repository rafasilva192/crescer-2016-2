
-- History ----------------------------
Rem    MODIFIER   (DD/MM/YYYY)  Notes
Rem    dslavov     01/09/2010 - Created
---------------------------------------

PROMPT Upgrade procedure can not continue, because of insufficient privileges. 
PROMPT Check the file Reporting_Schema_Permissions.sql.
PROMPT 