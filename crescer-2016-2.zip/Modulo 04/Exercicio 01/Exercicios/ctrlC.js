var ctrlC = function(obj){
  var newObject = JSON.parse(JSON.stringify(obj));
  return newObject;
}
