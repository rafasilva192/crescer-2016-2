function subtrair(num){
 return function(numero){
     return num-numero
   }
}
